module.exports = require("nativescript-push-notifications/hooks/before-prepare.js");
